package com.codewithkael.javawebrtcyoutube.utils;

public interface NewEventCallBack {
    void onNewEventReceived(DataModel model);
}
